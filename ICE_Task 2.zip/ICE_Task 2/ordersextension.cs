﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICE_Task_2
{
    static class OrderExtensions
    {
        public static double ApplyDiscount(this Order order, double percentage)
        {
            return order.TotalAmount - (order.TotalAmount * (percentage / 100));
        }
    }
}
