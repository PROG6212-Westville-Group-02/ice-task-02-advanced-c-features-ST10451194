﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICE_Task_2
{
    internal class Order
    {
        private List<Item> items = new List<Item>();

        // Indexer to access items by index
        public Item this[int index]
        {
            get { return items[index]; }
            set { items[index] = value; }
        }

        public void AddItem(Item item) => items.Add(item);

        public double TotalAmount => items.Sum(i => i.Price);

        public int ItemCount => items.Count;

        // Operator Overloading (+) → Combine two orders
        public static Order operator +(Order o1, Order o2)
        {
            Order combined = new Order();
            foreach (var item in o1.items) combined.AddItem(item);
            foreach (var item in o2.items) combined.AddItem(item);
            return combined;
        }

        public IEnumerable<Item> GetItems() => items;
    }
}
