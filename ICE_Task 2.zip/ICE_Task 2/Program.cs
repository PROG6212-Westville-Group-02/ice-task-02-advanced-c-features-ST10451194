﻿namespace ICE_Task_2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            /*Background:
            A small retail shop wants to track customer orders. Customers can order multiple items, and the shop owner wants to:
            ->Store items in an order and retrieve them easily (using indexers).
            ->Combine two orders into one (using operator overloading).
            ->Add a way to calculate discounts without modifying the original class (using extension methods).
            ->Display order summaries quickly (using anonymous types).
            */


            Console.WriteLine("=== Retail Shop Order System ===");
            Order order1 = new Order();

            Console.Write("How many items do you want to add to Order 1? ");
            int count1 = int.Parse(Console.ReadLine());

            for (int i = 0; i < count1; i++)
            {
                Console.Write($"Enter item {i + 1} name: ");
                string name = Console.ReadLine();
                Console.Write($"Enter item {i + 1} price: ");
                double price = double.Parse(Console.ReadLine());
                order1.AddItem(new Item(name, price));
            }

            // Create another order
            Order order2 = new Order();
            Console.Write("How many items do you want to add to Order 2? ");
            int count2 = int.Parse(Console.ReadLine());

            for (int i = 0; i < count2; i++)
            {
                Console.Write($"Enter item {i + 1} name: ");
                string name = Console.ReadLine();
                Console.Write($"Enter item {i + 1} price: ");
                double price = double.Parse(Console.ReadLine());
                order2.AddItem(new Item(name, price));
            }

            // Combine orders using operator overloading
            Order combinedOrder = order1 + order2;

            Console.WriteLine("\n--- Combined Order Summary ---");
            for (int i = 0; i < combinedOrder.ItemCount; i++)
            {
                Console.WriteLine($"{i + 1}. {combinedOrder[i].Name} - R{combinedOrder[i].Price}");
            }

            // Anonymous type for quick summary
            var summary = new
            {
                TotalItems = combinedOrder.ItemCount,
                OriginalTotal = combinedOrder.TotalAmount,
                DiscountedTotal = combinedOrder.ApplyDiscount(10) // Apply 10% discount
            };

            Console.WriteLine($"\nTotal Items: {summary.TotalItems}");
            Console.WriteLine($"Original Total: R{summary.OriginalTotal}");
            Console.WriteLine($"Total after 10% discount: R{summary.DiscountedTotal}");
        }
    }
}
